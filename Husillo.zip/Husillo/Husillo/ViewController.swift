//
//  ViewController.swift
//  Husillo
//
//  Created by user224967 on 10/3/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    
    @IBOutlet weak var tableV: UITableView!
    
    @IBOutlet weak var tfPassword: UITextField!
    
    var password: String!
    var which: String!
    var letterCount: Int = 4
    var numberCount: Int = 4
    var simbolCount: Int = 4
    var limit: Int = 15
    
    var arrPasswords = [Password(nombre: "This App", password: "12345678abc!!!"), Password(nombre: "ejemplo2", password: "mala contra")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPasswords.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda")!
        
        cell.textLabel?.text = arrPasswords[indexPath.row].nombre
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "editar", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "create"{
            let vistaInsertar = segue.destination as! ViewControllerInsert
            vistaInsertar.password = tfPassword.text
        }
        
        if segue.identifier == "options"{
            let vistaOptions = segue.destination as! ViewControllerOptions
            vistaOptions.simbolAmount = simbolCount
            vistaOptions.letterAmount = letterCount
            vistaOptions.numberAmount = numberCount
            vistaOptions.vistaInicial = self
            
        }
        
        if segue.identifier == "editar"{
            let vistaEditar = segue.destination as! ViewControllerEdit
            let indice = tableV.indexPathForSelectedRow!
            vistaEditar.nombre = arrPasswords[indice.row].nombre
            vistaEditar.contrasena = arrPasswords[indice.row].password
            vistaEditar.indice = indice.row
            vistaEditar.vistaInicial = self
        }
    }
        
    
    
    func agregarDatos(name: String!, contra: String!){
        let newPass = Password(nombre: name, password: contra)
        arrPasswords.append(newPass)
        tableV.reloadData()
    }
    
    func editarDatos(name: String!, contra: String!, place: Int!){
        arrPasswords[place].nombre = name
        arrPasswords[place].password = contra
        tableV.reloadData()
    }
    
    func editarCuenta(letAmount: Int!, numAmount: Int!, simAmount: Int!, newlimit: Int!){
         letterCount = letAmount
         numberCount = numAmount
         simbolCount = simAmount
         limit = newlimit
    }
    
    
    /*&func actualizarInterfaz(){
        let defaults = UserDefaults.standard
        let auxArray = defaults.object(forKey: "arrPasswords") as? [Password]
        if((auxArray?.isEmpty) != nil){
            
        }else{
         arrPasswords = auxArray!
        }
        let letterValue = defaults.integer(forKey: "letterIter")
        letterCount = letterValue
    }
    
    @IBAction func guardarDatosInterfaz(){
        let defaults = UserDefaults.standard
        defaults.set(arrPasswords, forKey: "arrayPasswords")
        defaults.set(letterCount, forKey: "letterIter")
        defaults.set(numberCount, forKey: "numberIter")
        defaults.set(simbolCount, forKey: "simbolIter")
    }*/

    @IBAction func generatePassworld(_ sender: UIButton) {
        let letterArray = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
        
        let numberArray = ["0","1","2","3","4","5","6","7","8","9"]
        
        let simbolArray = ["!","@","#","$","%","&","*","(",")","-","_","=","+",",",".","/","?","<",">",";",":"]
        
        let arrayArray = ["l","n","s"]
        
        password = letterArray.randomElement()
        var i = 0
        var letterCount = letterCount
        var numberCount = numberCount
        var simbolCount = simbolCount
        var limite = limit
        
        while i <= limite{
            which = arrayArray.randomElement()
            
            switch which{
                
            case "l":
                if(letterCount != 0){
                    password += letterArray.randomElement()!
                    letterCount = letterCount - 1
                }else{
                    if(numberCount != 0){
                        password += numberArray.randomElement()!
                        numberCount = numberCount - 1
                    }else{
                        if(simbolCount != 0){
                            password += simbolArray.randomElement()!
                            simbolCount = simbolCount - 1
                        }else{
                            password += letterArray.randomElement()!
                        }
                    }
                }
                
            case "n":
                
                if(numberCount != 0){
                    password += numberArray.randomElement()!
                    numberCount = numberCount - 1
                }else{
                    if(letterCount != 0){
                        password += letterArray.randomElement()!
                        letterCount = letterCount - 1
                    }else{
                        if(simbolCount != 0){
                            password += simbolArray.randomElement()!
                            simbolCount = simbolCount - 1
                        }else{
                            password += letterArray.randomElement()!
                        }
                    }
                }
                
            case "s":
                if(simbolCount != 0){
                    password += simbolArray.randomElement()!
                    simbolCount = simbolCount - 1
                }else{
                    if(letterCount != 0){
                        password += letterArray.randomElement()!
                        letterCount = letterCount - 1
                    }else{
                        if(numberCount != 0){
                            password += numberArray.randomElement()!
                            numberCount = numberCount - 1
                        }else{
                            password += letterArray.randomElement()!
                        }
                    }
                }
            default:
                password += letterArray.randomElement()!
            }
            i = i + 1
        }
        
        tableV.reloadData()
        tfPassword.text = password
    }
    
}


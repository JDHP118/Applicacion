//
//  ViewControllerOptions.swift
//  Husillo
//
//  Created by user224967 on 11/17/22.
//

import UIKit

class ViewControllerOptions: UIViewController {

    @IBOutlet weak var lbNumbers: UILabel!
    
    @IBOutlet weak var lbLetters: UILabel!
    
    @IBOutlet weak var lbSimbols: UILabel!
    
    var letterAmount: Int!
    var numberAmount: Int!
    var simbolAmount: Int!
    var limitAmount: Int!
    
    var vistaInicial: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbNumbers.text = String(numberAmount)
        lbLetters.text = String(letterAmount)
        lbSimbols.text = String(simbolAmount)
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func saveAmount(_ sender: UIButton) {
        let total = letterAmount + numberAmount + simbolAmount
        let vistaIni = vistaInicial
        vistaIni!.editarCuenta(letAmount: letterAmount, numAmount: numberAmount, simAmount: simbolAmount, newlimit: total)
        dismiss(animated: true)
    }
    
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @IBAction func letterMore(_ sender: UIButton) {
        letterAmount = letterAmount + 1
        lbLetters.text = String(letterAmount)
    }
    
    @IBAction func letterLess(_ sender: UIButton) {
        letterAmount = letterAmount - 1
        lbLetters.text = String(letterAmount)
    }
    
    @IBAction func numberMore(_ sender: UIButton) {
        numberAmount = numberAmount + 1
        lbNumbers.text = String(numberAmount)
    }
    
    @IBAction func numberLess(_ sender: UIButton) {
        numberAmount = numberAmount - 1
        lbNumbers.text = String(numberAmount)
    }
    
    @IBAction func simbolMore(_ sender: UIButton) {
        simbolAmount = simbolAmount + 1
        lbSimbols.text = String(simbolAmount)
    }
    
    @IBAction func simbolLess(_ sender: UIButton) {
        simbolAmount = simbolAmount - 1
        lbSimbols.text = String(simbolAmount)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

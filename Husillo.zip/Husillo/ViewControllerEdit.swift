//
//  ViewControllerEdit.swift
//  Husillo
//
//  Created by user224967 on 11/3/22.
//

import UIKit

class ViewControllerEdit: UIViewController {

    @IBOutlet weak var tfNombre: UITextField!
    
    @IBOutlet weak var tfContra: UITextField!
    
    var nombre: String!
    var contrasena: String!
    var indice: Int!
    
    var vistaInicial: ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tfNombre.text = nombre
        tfContra.text = contrasena
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveNew(_ sender: UIButton) {
        let vistaIni = vistaInicial
        vistaIni!.editarDatos(name: tfNombre.text, contra: tfContra.text, place: indice)
        dismiss(animated: true)
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

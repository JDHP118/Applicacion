//
//  ViewControllerPassword.swift
//  Husillo
//
//  Created by user224967 on 11/17/22.
//

import UIKit

class ViewControllerPassword: UIViewController {

    @IBOutlet weak var tfPassing: UITextField!
    

    var loginPass: String = "1234567"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func login(_ sender: UIButton) {
        
        if( tfPassing.text != loginPass){
            let alerta = UIAlertController(title: "ERROR", message: "Wrong password", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alerta.addAction(accion)
            present(alerta, animated: true, completion: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

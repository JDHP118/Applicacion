//
//  Password.swift
//  Husillo
//
//  Created by user224967 on 11/3/22.
//

import UIKit

class Password: NSObject{
    var nombre: String!
    var password: String!
    
    init(nombre: String, password: String){
        
        self.nombre = nombre
        self.password = password
        
    }

}
